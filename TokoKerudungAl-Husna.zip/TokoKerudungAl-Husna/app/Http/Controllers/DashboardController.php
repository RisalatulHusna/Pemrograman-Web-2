<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\User;
use App\Models\Barang;

class DashboardController extends Controller
{
    public function index()
    {
        $data['barang'] = Barang::all();

        return view('dashboard',$data);
    }

    public function showDataPengguna()
    {
        $data['users'] = User::all();

        return view('data_pengguna',$data);
    }

    public function showDataBarang()
    {
        $data['barang'] = Barang::all();

        return view('data_barang',$data);
    }

    public function tambahDataBarang()
    {
        return view('tambah_data_barang');
    }

    public function storeDataBarang(Request $request)
        {
            $namaInput = $request->input('namaInput');
            $hargaInput = $request->input('hargaInput');
            $jenisInput = $request->input('jenisInput');
            $bahanInput = $request->input('bahanInput');
            $ukuranInput = $request->input('ukuranInput');
            $finishingInput = $request->input('finishingInput');

            // dd($request->input(''));

            $query = DB::table('barang')->insert([
                'nama' => $namaInput,
                'harga' => $hargaInput,
                'jenis' => $jenisInput,
                'bahan' => $bahanInput,
                'ukuran' => $ukuranInput,
                'finishing' => $finishingInput
            ]);

            if ($query) {
                return redirect()->route('barang')->with('success', 'Data Berhasil Ditambahkan');
            } else {
                return redirect()->route('barang')->with('failed', 'Data Gagal Ditambahkan');
            }
            }
    
    
}
