<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Barang;
use Illuminate\Support\Facades\DB;

class BarangController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data['barang'] = DB::table('barang')->get();
        return view('barang', $data);


    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('tambahBarang');
    }

public function store(Request $request)
    {
        $namaInput = $request->input('namaInput');
        $hargaInput = $request->input('hargaInput');
        $jenisInput = $request->input('jenisInput');
        $bahanInput = $request->input('bahanInput');
        $ukuranInput = $request->input('ukuranInput');
        $finishingInput = $request->input('finishingInput');

        // dd($request->input(''));

        $query = DB::table('barang')->insert([
            'nama' => $namaInput,
            'harga' => $hargaInput,
            'jenis' => $jenisInput,
            'bahan' => $bahanInput,
            'ukuran' => $ukuranInput,
            'finishing' => $finishingInput
        ]);

        if ($query) {
            return redirect()->route('barang')->with('success', 'Data Berhasil Ditambahkan');
        } else {
            return redirect()->route('barang')->with('failed', 'Data Gagal Ditambahkan');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $data['barang'] = DB::table('barang')->where('id', $id)->first();

        return view('edit_data_barang', $data);
    }

 public function update(Request $request, string $id)
    {
        $namaInput = $request->input('namaInput');
        $hargaInput = $request->input('hargaInput');
        $jenisInput = $request->input('jenisInput');
        $bahanInput = $request->input('bahanInput');
        $ukuranInput = $request->input('ukuranInput');
        $finishingInput = $request->input('finishingInput');

        $query = DB::table('barang')->where('id', $id)->update([
            'nama' => $namaInput,
            'harga' => $hargaInput,
            'jenis' => $jenisInput,
            'bahan' => $bahanInput,
            'ukuran' => $ukuranInput,
            'finishing' => $finishingInput
        ]);

        if ($query) {
            return redirect()->route('data_barang')->with('success', 'Data Berhasil Diupdate');
        } else {
            return redirect()->route('data_barang')->with('failed', 'Data Gagal Diupdate');
        }
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $query = DB::table('barang')->where('id', $id)->delete();

        if ($query) {
            return redirect()->route('barang')->with('success', 'Data Berhasil Dihapus');
        } else {
            return redirect()->route('barang')->with('failed', 'Data Gagal Dihapus');
        }
    }

}
