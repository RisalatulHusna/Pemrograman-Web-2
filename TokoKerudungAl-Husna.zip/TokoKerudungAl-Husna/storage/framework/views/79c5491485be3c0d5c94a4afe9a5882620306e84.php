<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title>Tutorial Laravel #21 : CRUD Eloquent Laravel - www.malasngoding.com</title>
    </head>
    <body>
        <div class="container">
            <div class="card mt-5">
                <div class="card-header text-center">
                   <strong>TAMBAH DATA BARANG</strong>
                </div>
                <div class="card-body">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('dashboard.showDataBarang')); ?>">Kembali</a>
                    <?php endif; ?>
                    <br/>
                    <br/>
                    
                    <form action="<?php echo e(route('barang.store')); ?>" method="POST">
 
                        <?php echo e(csrf_field()); ?>

 
                        <div class="mb-3">
                        <label for="nama_input" class="form-label">Nama</label>
                        <input type="text" class="form-control" id="nama_input" name="namaInput">
                    </div>
                    <div class="mb-3">
                        <label for="harga_input" class="form-label">Harga</label>
                        <input type="text" class="form-control" id="harga_input" name="hargaInput">
                    </div>
                    <div class="mb-3">
                        <label for="jenis_input" class="form-label">Jenis</label>
                        <input type="text" class="form-control" id="jenis_input" name="jenisInput">
                    </div>
                    <div class="mb-3">
                        <label for="bahan_input" class="form-label">Bahan</label>
                        <input type="text" class="form-control" id="bahan_input" name="bahanInput">
                    </div>
                    <div class="mb-3">
                        <label for="ukuran_input" class="form-label">Ukuran</label>
                        <input type="text" class="form-control" id="ukuran_input" name="ukuranInput">
                    </div>
                    <div class="mb-3">
                        <label for="finishing_input" class="form-label">Finishing</label>
                        <input type="text" class="form-control" id="finishing_input" name="finishingInput">
                    </div>

 
                        <div class="form-group">
                            <input type="submit" class="btn btn-success" value="Simpan">
                        </div>
 
                    </form>
 
                </div>
            </div>
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\praktikum5\resources\views/tambah_data.blade.php ENDPATH**/ ?>